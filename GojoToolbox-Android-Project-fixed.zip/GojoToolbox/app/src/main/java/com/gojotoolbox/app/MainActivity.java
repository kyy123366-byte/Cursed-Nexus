package com.gojotoolbox.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout intro, login;
    ScrollView dashboard;
    EditText key;
    TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        intro = findViewById(R.id.intro);
        login = findViewById(R.id.login);
        dashboard = findViewById(R.id.dashboard);
        key = findViewById(R.id.key);
        status = findViewById(R.id.status);

        new Handler().postDelayed(() -> {
            intro.setVisibility(View.GONE);
            login.setVisibility(View.VISIBLE);
        }, 2200);

        findViewById(R.id.loginBtn).setOnClickListener(v -> {
            String k = key.getText().toString().trim();
            if (k.length() < 4) {
                status.setText("Masukkan license/access key.");
                return;
            }
            status.setText("");
            login.setVisibility(View.GONE);
            dashboard.setVisibility(View.VISIBLE);
        });
    }

    public void info(View v) {
        Toast.makeText(this, "Modul demo siap dikembangkan untuk penggunaan berizin.", Toast.LENGTH_SHORT).show();
    }
}
