# Gojo Toolbox

Prototype Android app dengan:
- Intro anime-style bertema Gojo
- Login/license screen
- Dashboard toolbox
- Network/router diagnostics placeholder
- OSINT publik
- Official bot integrations
- Gemini CLI integration placeholder
- Tutorial, music, anime streaming

Catatan:
Fitur surveillance tanpa izin, OTP spam, account/group disruption, exploit, atau bypass login tidak disertakan.

Build:
1. Buka folder ini di Android Studio.
2. Sync Gradle.
3. Build > Build APK(s).
